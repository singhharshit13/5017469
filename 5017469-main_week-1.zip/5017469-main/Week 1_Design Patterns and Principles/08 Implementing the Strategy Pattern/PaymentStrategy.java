// PaymentStrategy.java
public interface PaymentStrategy {
    void pay(int amount);
}
